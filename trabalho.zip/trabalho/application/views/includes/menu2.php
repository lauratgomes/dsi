<ul>
    <li> <?php echo anchor('crud/create','Create Noticias') ?> </li>
    <li> <?php echo anchor('crud/retrieve','Retrieve Noticias') ?> </li>
    <li> <?php echo anchor('crud/logout', 'Logout') ?> </li>
    
</ul>