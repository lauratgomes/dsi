<ul>
    <li> <?php echo anchor('crud/create','Create Noticias') ?> </li>
    <li> <?php echo anchor('crud/retrieve','Retrieve Noticias') ?> </li>
    <li> <?php echo anchor('crud/update','Update Noticias') ?> </li>
    <li> <?php echo anchor('crud/delete','Delete Noticias') ?> </li>
    <li> <?php echo anchor('crud/logout', 'Logout') ?> </li>
</ul>