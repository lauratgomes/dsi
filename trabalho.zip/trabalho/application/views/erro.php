<br />
<br />
<br />
<div class="alert alert-warning">
  <strong>Sinto muito!</strong> Você não tem permissão.
</div>